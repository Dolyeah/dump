﻿using System;
using System.Collections.Generic;
using System.Net.Http;
using System.Threading.Tasks;
using Newtonsoft.Json;
using Newtonsoft.Json.Linq;
using System.Linq;
using System.Text;

namespace RFIDAttendance
{
    public class FirebaseService
    {
        private readonly string _baseUrl = "https://thesis151515-default-rtdb.asia-southeast1.firebasedatabase.app/";
        private readonly HttpClient _httpClient;

        public FirebaseService()
        {
            _httpClient = new HttpClient();
        }

        public async Task<Employee> GetEmployeeByRFID(string rfidTag)
        {
            try
            {
                var response = await _httpClient.GetAsync($"{_baseUrl}EmployeeDetails.json");
                if (response.IsSuccessStatusCode)
                {
                    var json = await response.Content.ReadAsStringAsync();
                    Console.WriteLine($"Raw EmployeeDetails JSON: {json}"); // Debug log

                    var employeesDict = JsonConvert.DeserializeObject<Dictionary<string, FirebaseEmployee>>(json);

                    if (employeesDict != null)
                    {
                        foreach (var kvp in employeesDict)
                        {
                            var firebaseEmployee = kvp.Value;
                            Console.WriteLine($"Checking employee: {firebaseEmployee.first_name} {firebaseEmployee.last_name} with RFID: {firebaseEmployee.rfid_tag}"); // Debug log

                            if (firebaseEmployee.rfid_tag == rfidTag && firebaseEmployee.rfid_tag != "N/A")
                            {
                                var employee = new Employee
                                {
                                    EmployeeId = firebaseEmployee.employee_id,
                                    FirstName = firebaseEmployee.first_name,
                                    LastName = firebaseEmployee.last_name,
                                    RFIDTag = firebaseEmployee.rfid_tag
                                };

                                await AddEmploymentInfo(employee);
                                Console.WriteLine($"Found employee: {employee.FirstName} {employee.LastName}"); // Debug log
                                return employee;
                            }
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine($"Error getting employee: {ex.Message}");
            }
            return null;
        }

        private async Task AddEmploymentInfo(Employee employee)
        {
            try
            {
                var response = await _httpClient.GetAsync($"{_baseUrl}EmploymentInfo.json");
                if (response.IsSuccessStatusCode)
                {
                    var json = await response.Content.ReadAsStringAsync();
                    Console.WriteLine($"Raw EmploymentInfo JSON: {json}"); // Debug log

                    var empInfos = JsonConvert.DeserializeObject<Dictionary<string, JObject>>(json);

                    if (empInfos != null)
                    {
                        foreach (var kvp in empInfos)
                        {
                            var empInfo = kvp.Value;
                            var empId = empInfo["employee_id"]?.ToString();

                            if (empId == employee.EmployeeId)
                            {
                                employee.Department = empInfo["department"]?.ToString() ?? "";
                                employee.Position = empInfo["position"]?.ToString() ?? "";
                                Console.WriteLine($"Added employment info: {employee.Department} - {employee.Position}"); // Debug log
                                break;
                            }
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine($"Error getting employment info: {ex.Message}");
            }
        }

        public async Task<AttendanceRecord> GetTodaysAttendance(string employeeId)
        {
            try
            {
                var response = await _httpClient.GetAsync($"{_baseUrl}Attendance.json");
                if (response.IsSuccessStatusCode)
                {
                    var json = await response.Content.ReadAsStringAsync();
                    var today = DateTime.Today;

                    if (json.StartsWith("["))
                    {
                        var attendanceList = JsonConvert.DeserializeObject<List<AttendanceRecord>>(json);
                        if (attendanceList != null)
                        {
                            return attendanceList.FirstOrDefault(a =>
                                a.EmployeeId == employeeId &&
                                a.AttendanceDate.Date == today);
                        }
                    }
                    else
                    {
                        var attendanceDict = JsonConvert.DeserializeObject<Dictionary<string, AttendanceRecord>>(json);
                        if (attendanceDict != null)
                        {
                            return attendanceDict.Values.FirstOrDefault(a =>
                                a.EmployeeId == employeeId &&
                                a.AttendanceDate.Date == today);
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine($"Error getting attendance: {ex.Message}");
            }
            return null;
        }

        public async Task<bool> SaveOrUpdateAttendance(AttendanceRecord record)
        {
            try
            {
                var existingRecord = await GetTodaysAttendance(record.EmployeeId);

                if (existingRecord == null)
                {
                    return await CreateAttendanceRecord(record);
                }
                else
                {
                    return await UpdateAttendanceRecord(existingRecord, record);
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine($"Error saving attendance: {ex.Message}");
                return false;
            }
        }

        private async Task<bool> CreateAttendanceRecord(AttendanceRecord record)
        {
            try
            {
                var response = await _httpClient.GetAsync($"{_baseUrl}Attendance.json");
                if (response.IsSuccessStatusCode)
                {
                    var json = await response.Content.ReadAsStringAsync();
                    var attendanceList = new List<AttendanceRecord>();

                    if (!string.IsNullOrEmpty(json) && json != "null")
                    {
                        if (json.StartsWith("["))
                        {
                            attendanceList = JsonConvert.DeserializeObject<List<AttendanceRecord>>(json) ?? new List<AttendanceRecord>();
                        }
                        else
                        {
                            var attendanceDict = JsonConvert.DeserializeObject<Dictionary<string, AttendanceRecord>>(json);
                            if (attendanceDict != null)
                            {
                                attendanceList = attendanceDict.Values.ToList();
                            }
                        }
                    }

                    attendanceList.Add(record);

                    var updatedJson = JsonConvert.SerializeObject(attendanceList);
                    var content = new StringContent(updatedJson, Encoding.UTF8, "application/json");

                    var putResponse = await _httpClient.PutAsync($"{_baseUrl}Attendance.json", content);
                    return putResponse.IsSuccessStatusCode;
                }
                return false;
            }
            catch (Exception ex)
            {
                Console.WriteLine($"Error creating attendance: {ex.Message}");
                return false;
            }
        }

        private async Task<bool> UpdateAttendanceRecord(AttendanceRecord existingRecord, AttendanceRecord newRecord)
        {
            try
            {
                var response = await _httpClient.GetAsync($"{_baseUrl}Attendance.json");
                if (response.IsSuccessStatusCode)
                {
                    var json = await response.Content.ReadAsStringAsync();
                    var today = DateTime.Today;

                    if (json.StartsWith("["))
                    {
                        var attendanceList = JsonConvert.DeserializeObject<List<AttendanceRecord>>(json);
                        if (attendanceList != null)
                        {
                            var index = attendanceList.FindIndex(a =>
                                a.EmployeeId == newRecord.EmployeeId &&
                                a.AttendanceDate.Date == today);

                            if (index >= 0)
                            {
                                attendanceList[index] = newRecord;

                                var updatedJson = JsonConvert.SerializeObject(attendanceList);
                                var content = new StringContent(updatedJson, Encoding.UTF8, "application/json");

                                var putResponse = await _httpClient.PutAsync($"{_baseUrl}Attendance.json", content);
                                return putResponse.IsSuccessStatusCode;
                            }
                        }
                    }
                    else
                    {
                        var attendanceDict = JsonConvert.DeserializeObject<Dictionary<string, AttendanceRecord>>(json);
                        if (attendanceDict != null)
                        {
                            var key = attendanceDict.FirstOrDefault(a =>
                                a.Value.EmployeeId == newRecord.EmployeeId &&
                                a.Value.AttendanceDate.Date == today).Key;

                            if (key != null)
                            {
                                var updateJson = JsonConvert.SerializeObject(newRecord);
                                var content = new StringContent(updateJson, Encoding.UTF8, "application/json");

                                var putResponse = await _httpClient.PutAsync($"{_baseUrl}Attendance/{key}.json", content);
                                return putResponse.IsSuccessStatusCode;
                            }
                        }
                    }
                }
                return false;
            }
            catch (Exception ex)
            {
                Console.WriteLine($"Error updating attendance: {ex.Message}");
                return false;
            }
        }
    }
}