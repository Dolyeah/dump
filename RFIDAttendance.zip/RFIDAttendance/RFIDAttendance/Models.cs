﻿using System;
using System.Collections.Generic;

namespace RFIDAttendance
{
    public class Employee
    {
        public string EmployeeId { get; set; }
        public string FirstName { get; set; }
        public string LastName { get; set; }
        public string RFIDTag { get; set; }
        public string Department { get; set; }
        public string Position { get; set; }
    }

    // This class matches the exact JSON structure from Firebase
    public class FirebaseEmployee
    {
        public string address { get; set; }
        public string contact { get; set; }
        public string created_at { get; set; }
        public string date_of_birth { get; set; }
        public string email { get; set; }
        public string employee_id { get; set; }
        public string first_name { get; set; }
        public string gender { get; set; }
        public string last_name { get; set; }
        public string marital_status { get; set; }
        public string middle_name { get; set; }
        public string nationality { get; set; }
        public string rfid_tag { get; set; }
    }

    public class AttendanceRecord
    {
        public string EmployeeId { get; set; }
        public DateTime AttendanceDate { get; set; }
        public DateTime? TimeIn { get; set; }
        public DateTime? TimeOut { get; set; }
        public DateTime? OvertimeIn { get; set; }
        public DateTime? OvertimeOut { get; set; }
        public string Status { get; set; }
        public decimal HoursWorked { get; set; }
        public decimal OvertimeHours { get; set; }
        public string VerificationMethod { get; set; } = "RFID";
    }

    public class RFIDAttendanceState
    {
        public string RFIDTag { get; set; }
        public DateTime LastTapTime { get; set; }
        public TapState CurrentState { get; set; }
        public string EmployeeId { get; set; }
    }

    public enum TapState
    {
        WaitingForIn,
        WaitingForOut,
        WaitingForOvertimeIn,
        WaitingForOvertimeOut
    }

    public class AttendanceResult
    {
        public bool Success { get; set; }
        public string Message { get; set; }
        public string EmployeeName { get; set; }
        public string Action { get; set; }
        public DateTime Timestamp { get; set; }
    }
}