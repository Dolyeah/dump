﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace RFIDAttendance
{
    public partial class RFIDAttendanceSystem : Form
    {
        private RFIDAttendanceService _attendanceService;
        private TextBox rfidTextBox;
        private Label statusLabel;
        private Label employeeLabel;
        private Label actionLabel;
        private Label timeLabel;

        public RFIDAttendanceSystem()
        {
            InitializeComponent();
            _attendanceService = new RFIDAttendanceService();
            InitializeCustomComponents();
        }

        private void InitializeCustomComponents()
        {
            // RFID Input Label
            Label rfidInputLabel = new Label();
            rfidInputLabel.Text = "Scan RFID Tag:";
            rfidInputLabel.Font = new Font("Arial", 10);
            rfidInputLabel.AutoSize = true;
            rfidInputLabel.Location = new Point(20, 20);
            this.Controls.Add(rfidInputLabel);

            // RFID Input TextBox
            rfidTextBox = new TextBox();
            rfidTextBox.Location = new Point(150, 18);
            rfidTextBox.Size = new Size(200, 25);
            rfidTextBox.Font = new Font("Arial", 10);
            rfidTextBox.KeyPress += RfidTextBox_KeyPress;
            this.Controls.Add(rfidTextBox);

            // Status display
            statusLabel = new Label();
            statusLabel.Text = "Status: Ready";
            statusLabel.Font = new Font("Arial", 10);
            statusLabel.AutoSize = true;
            statusLabel.Location = new Point(20, 60);
            statusLabel.ForeColor = Color.Blue;
            this.Controls.Add(statusLabel);

            // Employee info display
            employeeLabel = new Label();
            employeeLabel.Text = "Employee: -";
            employeeLabel.Font = new Font("Arial", 10);
            employeeLabel.AutoSize = true;
            employeeLabel.Location = new Point(20, 90);
            this.Controls.Add(employeeLabel);

            // Action display
            actionLabel = new Label();
            actionLabel.Text = "Last Action: -";
            actionLabel.Font = new Font("Arial", 10);
            actionLabel.AutoSize = true;
            actionLabel.Location = new Point(20, 120);
            this.Controls.Add(actionLabel);

            // Time display
            timeLabel = new Label();
            timeLabel.Text = "Time: -";
            timeLabel.Font = new Font("Arial", 10);
            timeLabel.AutoSize = true;
            timeLabel.Location = new Point(20, 150);
            this.Controls.Add(timeLabel);
        }

        private async void RfidTextBox_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar == (char)Keys.Enter)
            {
                e.Handled = true;
                await ProcessRFID(rfidTextBox.Text);
                rfidTextBox.Clear();
                rfidTextBox.Focus();
            }
        }

        private async Task ProcessRFID(string rfidTag)
        {
            try
            {
                statusLabel.Text = "Status: Processing...";
                statusLabel.ForeColor = Color.Orange;
                this.Refresh();

                Console.WriteLine($"Processing RFID: {rfidTag}"); // Debug log

                var result = await _attendanceService.ProcessRFIDTap(rfidTag);

                if (result.Success)
                {
                    statusLabel.Text = "Status: Success";
                    statusLabel.ForeColor = Color.Green;
                    employeeLabel.Text = $"Employee: {result.EmployeeName}";
                    actionLabel.Text = $"Last Action: {result.Action}";
                    timeLabel.Text = $"Time: {result.Timestamp:HH:mm:ss}";
                }
                else
                {
                    statusLabel.Text = "Status: Error";
                    statusLabel.ForeColor = Color.Red;
                    employeeLabel.Text = "Employee: -";
                    actionLabel.Text = $"Error: {result.Message}";
                    timeLabel.Text = $"Time: {DateTime.Now:HH:mm:ss}";

                    // Show detailed error
                    MessageBox.Show($"RFID Error: {result.Message}\n\nRFID Tag: {rfidTag}", "Attendance Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
            catch (Exception ex)
            {
                statusLabel.Text = "Status: System Error";
                statusLabel.ForeColor = Color.Red;
                actionLabel.Text = $"System Error: {ex.Message}";
                timeLabel.Text = $"Time: {DateTime.Now:HH:mm:ss}";

                MessageBox.Show($"System Error: {ex.Message}", "System Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void RFIDAttendanceSystem_Load(object sender, EventArgs e)
        {
            this.Text = "RFID Attendance System";
            this.Size = new Size(400, 200);
            this.StartPosition = FormStartPosition.CenterScreen;
        }
    }
}