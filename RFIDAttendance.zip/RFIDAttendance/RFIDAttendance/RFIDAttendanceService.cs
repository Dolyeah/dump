﻿using System;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace RFIDAttendance
{
    public class RFIDAttendanceService
    {
        private FirebaseService _firebaseService;
        private Dictionary<string, RFIDAttendanceState> _activeSessions;

        public RFIDAttendanceService()
        {
            _firebaseService = new FirebaseService();
            _activeSessions = new Dictionary<string, RFIDAttendanceState>();
        }

        public async Task<AttendanceResult> ProcessRFIDTap(string rfidTag)
        {
            try
            {
                var employee = await _firebaseService.GetEmployeeByRFID(rfidTag);
                if (employee == null)
                {
                    return new AttendanceResult 
                    { 
                        Success = false, 
                        Message = "Employee not found for RFID tag." 
                    };
                }

                if (!_activeSessions.TryGetValue(rfidTag, out var session))
                {
                    session = new RFIDAttendanceState
                    {
                        RFIDTag = rfidTag,
                        EmployeeId = employee.EmployeeId,
                        CurrentState = TapState.WaitingForIn,
                        LastTapTime = DateTime.Now
                    };
                    _activeSessions[rfidTag] = session;
                }

                var result = await ProcessTapByState(session, employee);
                session.LastTapTime = DateTime.Now;

                return result;
            }
            catch (Exception ex)
            {
                return new AttendanceResult 
                { 
                    Success = false, 
                    Message = $"Error: {ex.Message}" 
                };
            }
        }

        private async Task<AttendanceResult> ProcessTapByState(RFIDAttendanceState session, Employee employee)
        {
            var currentTime = DateTime.Now;
            var todayRecord = await _firebaseService.GetTodaysAttendance(session.EmployeeId) ?? 
                             new AttendanceRecord 
                             { 
                                 EmployeeId = session.EmployeeId,
                                 AttendanceDate = DateTime.Today,
                                 Status = "On Time"
                             };

            AttendanceResult result;

            switch (session.CurrentState)
            {
                case TapState.WaitingForIn:
                    result = ProcessTimeIn(session, employee, todayRecord, currentTime);
                    break;
                case TapState.WaitingForOut:
                    result = ProcessTimeOut(session, employee, todayRecord, currentTime);
                    break;
                case TapState.WaitingForOvertimeIn:
                    result = ProcessOvertimeIn(session, employee, todayRecord, currentTime);
                    break;
                case TapState.WaitingForOvertimeOut:
                    result = ProcessOvertimeOut(session, employee, todayRecord, currentTime);
                    break;
                default:
                    result = new AttendanceResult { Success = false, Message = "Invalid state." };
                    break;
            }

            if (result.Success)
            {
                await _firebaseService.SaveOrUpdateAttendance(todayRecord);
            }

            return result;
        }

        private AttendanceResult ProcessTimeIn(RFIDAttendanceState session, Employee employee, 
                                         AttendanceRecord record, DateTime currentTime)
        {
            record.TimeIn = currentTime;
            session.CurrentState = TapState.WaitingForOut;

            return new AttendanceResult
            {
                Success = true,
                Message = $"Time IN recorded successfully",
                EmployeeName = $"{employee.FirstName} {employee.LastName}",
                Action = "Time In",
                Timestamp = currentTime
            };
        }

        private AttendanceResult ProcessTimeOut(RFIDAttendanceState session, Employee employee, 
                                          AttendanceRecord record, DateTime currentTime)
        {
            record.TimeOut = currentTime;
            
            if (record.TimeIn.HasValue)
            {
                record.HoursWorked = (decimal)(currentTime - record.TimeIn.Value).TotalHours;
            }

            if (currentTime.Hour >= 17)
            {
                session.CurrentState = TapState.WaitingForOvertimeIn;
                return new AttendanceResult
                {
                    Success = true,
                    Message = $"Time OUT recorded. Ready for OVERTIME.",
                    EmployeeName = $"{employee.FirstName} {employee.LastName}",
                    Action = "Time Out",
                    Timestamp = currentTime
                };
            }
            else
            {
                session.CurrentState = TapState.WaitingForIn;
                return new AttendanceResult
                {
                    Success = true,
                    Message = $"Time OUT recorded. Have a great day!",
                    EmployeeName = $"{employee.FirstName} {employee.LastName}",
                    Action = "Time Out",
                    Timestamp = currentTime
                };
            }
        }

        private AttendanceResult ProcessOvertimeIn(RFIDAttendanceState session, Employee employee, 
                                             AttendanceRecord record, DateTime currentTime)
        {
            record.OvertimeIn = currentTime;
            session.CurrentState = TapState.WaitingForOvertimeOut;

            return new AttendanceResult
            {
                Success = true,
                Message = $"Overtime IN recorded",
                EmployeeName = $"{employee.FirstName} {employee.LastName}",
                Action = "Overtime In",
                Timestamp = currentTime
            };
        }

        private AttendanceResult ProcessOvertimeOut(RFIDAttendanceState session, Employee employee, 
                                              AttendanceRecord record, DateTime currentTime)
        {
            record.OvertimeOut = currentTime;
            
            if (record.OvertimeIn.HasValue)
            {
                record.OvertimeHours = (decimal)(currentTime - record.OvertimeIn.Value).TotalHours;
            }

            session.CurrentState = TapState.WaitingForIn;

            return new AttendanceResult
            {
                Success = true,
                Message = $"Overtime OUT recorded. Good work!",
                EmployeeName = $"{employee.FirstName} {employee.LastName}",
                Action = "Overtime Out",
                Timestamp = currentTime
            };
        }
    }
}